// HelloTest.cpp : �������̨Ӧ�ó������ڵ㡣
//

#include "stdafx.h"
#include "behaviac_generated/types/behaviac_types.h"
#define LOGI printf

// ��Ϊ���б�
static behaviac::string g_arrBTPath[] = { "FirstBT", "1_Attach", "2_Condition", "3_Action", "4_Combine", "5_Combine_2",
"6_Adorner", "7_StateMachine" };

FirstAgent* g_pFirstAgent = nullptr;
FirstAgent* g_arrMultiAgent[_countof(g_arrBTPath)] = { nullptr };
ULONGLONG g_ullStartTick = ::GetTickCount64();
int g_nBTIndex = 0;

bool InitBehaviac()
{
	LOGI("%s\n", __FUNCTION__);
	behaviac::Workspace::GetInstance()->SetFilePath("../res");	// �������ü��ر༭����������Ϊ�����ڵ�Ŀ¼
	behaviac::Workspace::GetInstance()->SetFileFormat(behaviac::Workspace::EFF_xml);		// �������ü��ص���Ϊ����ʽ�������õ���xml��ʽ��
	//behaviac::Config::SetSocketBlocking(true);	// �ȴ��༭�������ϲ��������ִ��
	//behaviac::Config::SetSocketPort(60636);	// �����Ҫ�޸Ķ˿ںţ���Ҫ���Ӵ˴���
	return true;
}

bool InitPlayer()
{
	const char* szPath = g_arrBTPath[g_nBTIndex].c_str();

	LOGI("%s\n", __FUNCTION__);
	g_pFirstAgent = behaviac::Agent::Create<FirstAgent>();	//Create()���ڴ���Agent�����ʵ��
	if (g_pFirstAgent == nullptr)
	{
		return false;
	}

	bool bRet = g_pFirstAgent->btload(szPath);	//���ڼ�����Ϊ������ڲ�������Ϊ�������֣�����Ҫ�Ӻ�׺
	if (bRet)
	{
		g_pFirstAgent->btsetcurrent(szPath);		//����ָ����ǰ׼��ִ�е���Ϊ��
	}

	return bRet;
}


void UpdateLoop()
{
	LOGI("%s\n", __FUNCTION__);
	int frames = 0;
	behaviac::EBTStatus enStatus = behaviac::BT_RUNNING;
	while (enStatus == behaviac::BT_RUNNING)
	{
		behaviac::Workspace::GetInstance()->SetDoubleValueSinceStartup((::GetTickCount64() - g_ullStartTick));
		behaviac::Workspace::GetInstance()->SetFrameSinceStartup(++frames);
		LOGI("frame %d:\n", frames);
		//behaviac::Workspace::GetInstance()->DebugUpdate();
		enStatus = g_pFirstAgent->btexec();

		if (frames == 10 && (g_nBTIndex == 5 || g_nBTIndex == 0))
		{
			g_pFirstAgent->FireEvent("event_task", 10);
		}

		if (g_nBTIndex == 7 && frames == 10)
		{
			g_pFirstAgent->SetInt(2);
		}
	}
}


void CleanPlayer()
{
	LOGI("%s\n", __FUNCTION__);
	behaviac::Agent::Destroy(g_pFirstAgent);
}


void CleanBehaviac()
{
	LOGI("%s\n", __FUNCTION__);
	behaviac::Workspace::GetInstance()->Cleanup();
}


void RunOneTest()
{
	InitBehaviac();
	InitPlayer();

	UpdateLoop();

	CleanPlayer();
	CleanBehaviac();
}


bool InitMultiPlayer()
{
	for (int nIndex = 0; nIndex < _countof(g_arrMultiAgent); ++nIndex)
	{
		FirstAgent* pAgent = behaviac::Agent::Create<FirstAgent>();
		if (pAgent == nullptr)
		{
			return false;
		}

		const char* szPath = g_arrBTPath[nIndex].c_str();
		if (!pAgent->btload(szPath))
		{
			return false;
		}

		pAgent->btsetcurrent(szPath);
		g_arrMultiAgent[nIndex] = pAgent;
	}

	return true;
}


void UpdateLoopForMulti()
{
	int frames = 0;
	while (1)
	{
		behaviac::Workspace::GetInstance()->SetDoubleValueSinceStartup((::GetTickCount64() - g_ullStartTick));
		behaviac::Workspace::GetInstance()->SetFrameSinceStartup(++frames);
		LOGI("frame %d:\n", frames);
		behaviac::Workspace::GetInstance()->Update();

		if (frames == 10)
		{
			g_arrMultiAgent[5]->FireEvent("event_task", 10);
			g_arrMultiAgent[0]->FireEvent("event_task", 10);
			g_arrMultiAgent[7]->SetInt(2);
		}
	}
}


void CleanMultiPlayer()
{
	for (int nIndex = 0; nIndex < _countof(g_arrMultiAgent); ++nIndex)
	{
		behaviac::Agent::Destroy(g_arrMultiAgent[nIndex]);
	}
}


void RunMultiTest()
{
	InitBehaviac();
	InitMultiPlayer();
	UpdateLoopForMulti();
	CleanMultiPlayer();
	CleanBehaviac();
}


int _tmain(int argc, _TCHAR* argv[])
{
	RunOneTest();
	system("pause");
	return 0;
}

